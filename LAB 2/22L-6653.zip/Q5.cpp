//#include<iostream>
//using namespace std;
//int ispalindrome(char* str)
//{
//	char *stri =&str[ strlen(str) - 1];
//	int flag = 1;
//	while (str<stri)
//	{
//		if (*str!=*stri)
//		{
//			flag = 0;
//		}
//		str++;
//		stri--;
//	}
//	return flag;
//}
//int main()
//{
//	char str[100];
//	cin >> str;
//	cout << ispalindrome(str);
//}
//
