//#include<iostream>
//using namespace std;
//int main()
//{
//	int* arr1 = new int[5];
//	int* arr2 = new int[5];
//	int* temp1;
//	int* temp2;
//	temp1 = arr1;
//	temp2 = arr2;
//	for (int i = 0; i < 5; i++)
//	{
//		cin >> arr1[i];
//	}
//	for (int i = 0; i < 5; i++)
//	{
//		*arr2 = *arr1;
//		arr2++;
//		arr1++;
//	}
//	arr1 = temp1;
//	arr2 = temp2;
//	for (int i = 0; i < 5; i++)
//	{
//		cout << arr2[i] << endl;
//	}
//	delete[]arr1;
//	delete[]arr2;
//}
