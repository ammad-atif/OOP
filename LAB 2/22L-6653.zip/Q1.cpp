//#include<iostream>
//using namespace std;
//int main()
//{
//	int arr[5];
//	int* ptr = arr;
//	//input
//	for (int i = 0; i < 5; i++)
//	{
//		cin >> arr[i];
//	}
//	/*array subscript notation*/
//	for (int i = 0; i < 5; i++)
//	{
//		cout << arr[i] << endl;
//	}
//	//using pointer offeset notation
//	for (int i = 0; i < 5; i++)
//	{
//		cout << *(ptr + i) << endl;
//	}
//	//using pointer subscript notation
//	for (int i = 0; i < 5; i++)
//	{
//		cout << ptr[i] << endl;
//	}
//	//using offset notation
//	for (int i = 0; i < 5; i++)
//	{
//		cout << *(arr + i) << endl;
//	}
//}