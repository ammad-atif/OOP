//#include<iostream>
//#include<time.h>
//using namespace std;
//void func (int *& p, int s)
//{
//	p = new int[s];
//	srand(time(0));
//	for (int i = 0; i < s; i++)
//	{
//		p[i] = (rand()%100)+1;
//		p[i] = p[i] * p[i];
//	}
//}
//int main()
//{
//	int* p = nullptr;
//	int s;
//	cout << "Enter size:   ";
//	cin >> s;
//	func(p, s);
//	for (int i = 0; i < s; i++)
//	{
//		cout << p[i] << endl;
//	}
//	delete[]p;
//}