//#include<iostream>
//using namespace std;
//int fullsalary(int*s,int*b)
//{
//	int fs = *s + *b;
//	return fs;
//}
//int main()
//{
//	int salary;
//	int bonus;
//	int* s = &salary;
//	int* b = &bonus;
//	cout << "Enter salary:  " << endl;
//	cin >> salary;
//	cout << "Enter bonus:  " << endl;
//	cin >> bonus;
//	int fs = fullsalary(s, b);
//	cout <<"Full salary is:"<<endl<< fs;
//}