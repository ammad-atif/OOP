//#include<iostream>
//using namespace std;
//int check(int** matrix, int size)
//{
//	int r = 1, c =1, found = 1;
//	int i = 1;
//	while (i<size)
//	{
//		for (int j = c-1; j >=0; j--)
//		{
//			if (matrix[r][j]!=0)
//			{
//				found = 0;
//			}
//		}
//		c++;
//		r++;
//		i++;
//	}
//	return found;
//}
//int main()
//{
//	int size;
//	cout << "Enter size of square matrix: ";
//	cin >> size;
//	int** matrix = new int* [size];
//	for (int i = 0; i < size; i++)
//	{
//		matrix[i] = new int[size];
//	}
//	for (int i = 0; i < size; i++)
//	{
//		for (int j = 0; j < size; j++)
//		{
//			cout << "Enter " << i + 1 << " " << j + 1 << " Element of matrix: ";
//			cin >> matrix[i][j];
//		}
//	}
//	cout << check(matrix, size);
//	for (int  i = 0; i < size; i++)
//	{
//		delete[]matrix[i];
//	}
//	delete[]matrix;
//}