//#include<iostream>
//using namespace std;
//int main()
//{
//	char* word;
//	char** sentence;
//	int s;
//	int w; 
//	cout << "Enter numebr of words you want to enter to make a sentence: ";
//	cin >> s;
//	sentence = new char* [s];
//	for (int i = 0; i < s; i++)
//	{
//		cout << "Enter Number of alphabets for " << i + 1 << " word:  ";
//		cin >> w;
//		word = new char[w+1];
//		cout << "Enter word:  ";
//		cin.ignore();
//		cin.getline(word, w + 1);
//		sentence[i] = word;
//	}
//	cout << "The sentence is:  " << endl;
//	for (int i = 0; i < s; i++)
//	{
//		cout << sentence[i] << " ";
//	}
//	for (int i = 0; i < s; i++)
//	{
//		delete[]sentence[i];
//	}
//	delete[]sentence;
//}