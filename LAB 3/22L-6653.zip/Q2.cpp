//#include<iostream>
//using namespace std;
//int *MaxOfColumn(int** numbers, int r, int c)
//{
//	int* max_numbers = new int[c];
//	int max_i = 0;
//	for (int i = 0; i < c; i++)
//	{
//		for (int j = 0; j < r; j++)
//		{
//			if (numbers[j][i] > numbers[max_i][i])
//			{
//				max_i = j;
//			}
//		}
//		max_numbers[i] = numbers[max_i][i];
//		max_i = 0;
//	}
//	return max_numbers;
//}
//int main()
//{
//	int r, c;
//	cout << "Enter number of rows: ";
//	cin >> r;
//	cout << "Enter number of colums: ";
//	cin >> c;
//	int** numbers = new int* [r];
//	for (int i = 0; i < r; i++)
//	{
//		numbers[i] = new int[c];
//	}
//	for (int i = 0; i < r; i++)
//	{
//		for (int j = 0; j < c; j++)
//		{
//			cout << "Enter " << i + 1 << " " << j + 1 << " Element of matrix: ";
//			cin >> numbers[i][j];
//		}
//	}
//	int* max_numbers = MaxOfColumn(numbers, r, c);
//	for (int i = 0; i < c; i++)
//	{
//		cout << max_numbers[i] << endl;
//	}
//	for (int i = 0; i < r; i++)
//	{
//		delete[]numbers[i];
//	}
//	delete[]numbers;
//	delete[]max_numbers;
//}