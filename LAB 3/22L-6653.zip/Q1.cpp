//#include<iostream>
//using namespace std;
////so that input can also rmain in main and we could use it later in the functions
//int **AllocateMemory(int& row, int& col)
//{
//	cout << "Enter number of rows: ";
//	cin >> row;
//	cout << "Enter number of rows: ";
//	cin >> col;
//	int** matrix = new int* [row];
//	for (int i = 0; i < row; i++)
//	{
//		matrix[i] = new int[col];
//	}
//	return matrix;
//}
////so that values of them couldnot be edit in main and this function too
//void InputMatrix(int** matrix, const int& row, const int& col)
//{
//	for (int i = 0; i < row; i++)
//	{
//		for (int j = 0; j < col; j++)
//		{
//			cout << "Enter " << i + 1 << " " << j + 1 << " Element of matrix: ";
//			cin >> matrix[i][j];
//		}
//	}
//}
//void DisplayMatrix(int** matrix, const int& row, const int& col)
//{
//	for (int i = 0; i < row; i++)
//	{
//		for (int j = 0; j < col; j++)
//		{
//			cout << matrix[i][j] << " ";
//		}
//		cout << endl;
//	}
//}
////inline will speed up the execution of this function in main
//	inline void DeallocateMemory(int** matrix, const int& row)
//	{
//		for (int i = 0; i < row; i++)
//		{
//			delete[]matrix[i];
//		}
//		delete[]matrix;
//	}
//int main()
//{
//	int row, col;
//	int** matrix = AllocateMemory(row, col);
//	InputMatrix(matrix, row, col);
//	DisplayMatrix(matrix, row, col);
//	DeallocateMemory(matrix, row);
//}
