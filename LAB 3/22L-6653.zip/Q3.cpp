//#include<iostream>
//using namespace std;
//int main()
//{
//	int r, c;
//	cout << "Enter number of rows for matrix: ";
//	cin >> r;
//	cout << "Enter number of colums for matrix: ";
//	cin >> c;
//	int** numbers = new int* [r];
//	for (int i = 0; i < r; i++)
//	{
//		numbers[i] = new int[c];
//	}
//	for (int i = 0; i < r; i++)
//	{
//		for (int j = 0; j < c; j++)
//		{
//			cout << "Enter " << i + 1 << " " << j + 1 << " Element of matrix: ";
//			cin >> numbers[i][j];
//		}
//	}
//	int max_i = 0;
//	for (int i = 0; i < c; i++)
//	{
//		for (int k = r; k >0; k--)
//		{
//			for (int j = 0; j < k; j++)
//			{
//				if (numbers[j][i] > numbers[max_i][i])
//				{
//					max_i = j;
//				}
//			}
//			swap(numbers[k - 1][i] , numbers[max_i][i]);
//			max_i = 0;
//		}
//	}
//	for (int i = 0; i < r; i++)
//	{
//		for (int j = 0; j < c; j++)
//		{
//			cout << numbers[i][j] << ' ';
//		}
//		cout << endl;
//	}
//	for (int i = 0; i < r; i++)
//	{
//		delete[]numbers[i];
//	}
//	delete[]numbers;
//}